//� A+ Computer Science  -  www.apluscompsci.com
//Name -
//Date -
//Class -
//Lab  -

import static java.lang.System.*;

public class BiggestDouble
{
	private double one,two,three,four;

	public BiggestDouble()
	{
		this(0,0,0,0);
	}

	public BiggestDouble(double a, double b, double c, double d)
	{



	}

	public void setDoubles(double a, double b, double c, double d)
	{



	}

	public double getBiggest()
	{


		return 0.0;
	}

	public String toString()
	{
	   return "";
	}
}