//� A+ Computer Science  -  www.apluscompsci.com
//Name -
//Date -
//Class -
//Lab  -

import static java.lang.System.*;

public class TriangleFour
{
   private int size;
   private String letter;

	public TriangleFour()
	{
	}

	public TriangleFour(int count, String let)
	{
	}

	public void setTriangle( String let, int sz )
	{
	}

	public String getLetter()
	{
		return "#";
	}

	public String toString()
	{
		String output="";
		return output+"\n";
	}
}