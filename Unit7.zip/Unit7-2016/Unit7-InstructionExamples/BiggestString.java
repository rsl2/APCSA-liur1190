//� A+ Computer Science  -  www.apluscompsci.com
//Name -
//Date -
//Class -
//Lab  -

import static java.lang.System.*;

public class BiggestString
{
	private String one,two,three;

	public BiggestString()
	{
		this("","","");
	}

	public BiggestString(String a, String b, String c)
	{


	}

	public void setStrings(String a, String b, String c)
	{



	}

	public String getBiggest()
	{




		return "";
	}

	public String toString()
	{
	   return "";
	}
}