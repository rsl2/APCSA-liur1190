//� A+ Computer Science  -  www.apluscompsci.com
//Name -
//Date -
//Class -
//Lab  -

public class Lab10a
{
	public static void main( String args[] )
	{
		PasswordCheck test = new PasswordCheck();
		test.check();
	}
}