//� A+ Computer Science  -  www.apluscompsci.com
//Name -
//Date -
//Class - 
//Lab  -

import static java.lang.System.*;

public class Triples
{
   private int number;

	public Triples()
	{
		this(0);
	}

	public Triples(int num)
	{


	}

	public void setNum(int num)
	{


	}
	
	private int greatestCommonFactor(int a, int b, int c)
	{
		int max = 0;



		return 1;
	}

	public String toString()
	{
		String output="";






		return output+"\n";
	}
}