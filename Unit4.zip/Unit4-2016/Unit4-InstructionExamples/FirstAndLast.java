//� A+ Computer Science  -  www.apluscompsci.com
//Name -
//Date -
//Class -
//Lab  -

import static java.lang.System.*;

public class FirstAndLast
{
	private String word;
	private char firstLetter;
	private char lastLetter;

	public FirstAndLast()
	{


	}

	public FirstAndLast(String s)
	{



	}

	public void setString(String s)
	{


	}

	public void findFirstLastLetters()
	{



	}

 	public String toString()
 	{
 		String output="";




 		return output;
	}
}