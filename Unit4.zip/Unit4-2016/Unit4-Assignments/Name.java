//� A+ Computer Science  -  www.apluscompsci.com
//Name -
//Date -
//Class -
//Lab  -

import static java.lang.System.*;

public class Name
{
	private String name;

	public Name()
	{


	}

	public Name(String s)
	{


	}

   public void setName(String s)
   {


   }

	public String getFirst()
	{
		return "";
	}

	public String getLast()
	{
		return "";
	}

 	public String toString()
 	{
 		return "";
	}
}